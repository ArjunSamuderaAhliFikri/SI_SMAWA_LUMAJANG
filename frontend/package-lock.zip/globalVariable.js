const setPortURL = (sub) => {
  return `http://localhost:3000/${sub}`;
};

module.exports = setPortURL;
