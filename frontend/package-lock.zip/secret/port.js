export default function port(relativePath) {
  return `http://localhost:3000/${relativePath}`;
}
