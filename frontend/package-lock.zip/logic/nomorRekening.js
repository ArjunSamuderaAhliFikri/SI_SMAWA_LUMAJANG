import verifyUser from "../secret/verifyUser.js";

// verifyUser("/frontend/pages/auth/login.html");

const token = localStorage.getItem("token");

let inputAccountNumber = document.getElementById("input-nomor-rekening");
const inputOwnerAccountNumber = document.getElementById(
  "nama-pemilik-rekening"
);
const addAccountNumber = document.getElementById("add-nomor-rekening");
const inputAtasNama = document.getElementById("atas-nama");
let hidden = document.getElementById("account-number-popup-hidden");

const formUpdateAccountNumber = document.getElementById(
  "form-update-nomor-rekening"
);

// TODOOO
formUpdateAccountNumber.addEventListener("submit", (event) => {
  event.preventDefault();

  async function updateAccountNumber() {
    try {
      const response = await fetch(
        `https://api2.smawalmj.com/account-billing/${hidden.value}`,
        {
          method: "PUT",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            newAccountNumber: inputAccountNumber.value,
            atasNama: inputOwnerAccountNumber.value,
          }),
        }
      );

      if (response.ok) {
        const { msg, warn } = await response.json();

        if (warn) {
          window.location.href = "/";
        }
        Swal.fire(msg).then((result) => {
          if (result.isConfirmed) {
            window.location.reload();
          }
        });
      }
    } catch (error) {
      return error.message("Update data gagal!");
    }
  }

  updateAccountNumber();
});

const formDeletedAccountNumber = document.getElementById(
  "form-deleted-nomor-rekening"
);

// TODOOO
formDeletedAccountNumber.addEventListener("submit", (event) => {
  event.preventDefault();

  async function handleDeleteAccountNumber() {
    const response = await fetch(
      `https://api2.smawalmj.com/account-billing/${hidden.value}`,
      {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      }
    );

    if (response.ok) {
      const { msg, warn } = await response.json();

      if (warn) {
        window.location.href = "/";
      }

      Swal.fire(msg).then((result) => {
        if (result.isConfirmed) {
          window.location.reload();
        }
      });
    }
  }

  handleDeleteAccountNumber();
});

const bodyOfTable = document.querySelector("tbody");

document.addEventListener("DOMContentLoaded", () => {
  async function retrieveAccountNumber() {
    try {
      const response = await fetch(
        "https://api2.smawalmj.com/account-billing",
        {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (response.ok) {
        const { accounts, err, warn } = await response.json();

        if (warn) {
          window.location.href = "/";
        }

        if (err) {
          return alert(err);
        }

        accounts.forEach((data) => {
          const { id, atasNama, rekening, status } = data;
          const createTrElement = document.createElement("tr");
          createTrElement.setAttribute(
            "class",
            "cursor-pointer hover:bg-gray-100"
          );

          createTrElement.innerHTML = generateTdElement(
            atasNama,
            rekening,
            status
          );

          bodyOfTable.appendChild(createTrElement);
        });
      }

      const tdElements = document.querySelectorAll("td");
      tdElements.forEach((td) => {
        td.addEventListener("click", () => {
          const popup = document.getElementById("popup-update-nomor-rekening");

          const getNameAccountNumber = td.parentElement.firstChild.textContent;
          const getAccountNumber =
            td.parentElement.querySelectorAll("td")[1].textContent;
          console.log(getAccountNumber);

          hidden.value = getAccountNumber;
          inputOwnerAccountNumber.value = getNameAccountNumber;
          inputAccountNumber.value = getAccountNumber;

          popup.classList.replace("hidden", "flex");
        });
      });
    } catch (error) {
      alert(error);
    }
  }

  retrieveAccountNumber();
});

const buttonClosePopup = document.getElementById("close-popup");
buttonClosePopup.addEventListener("click", () => {
  const popup = document.getElementById("popup-update-nomor-rekening");
  popup.classList.replace("flex", "hidden");
});

const addAccountNumberForm = document.querySelector(
  "form[id=form-nomor-rekening]"
);

addAccountNumberForm.addEventListener("submit", (event) => {
  event.preventDefault();

  async function handleAddAccountNumber() {
    try {
      const response = await fetch(
        "https://api2.smawalmj.com/account-billing",
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            rekening: addAccountNumber.value,
            atasNama: inputAtasNama.value,
          }),
        }
      );

      if (response.ok) {
        const { msg, err, warn } = await response.json();

        if (warn) {
          window.location.href = "/";
        }

        if (err) {
          return Swal.fire(err).then((result) => {
            if (result.isConfirmed) {
              window.location.reload();
            }
          });
        }

        Swal.fire(msg).then((result) => {
          if (result.isConfirmed) {
            window.location.reload();
          }
        });
      }
    } catch (error) {
      return console.error(`Gagal menambahkan nomor rekening!, ${error}`);
    }
  }

  handleAddAccountNumber();
});

function generateTdElement(atasNama, nomorRekening, status) {
  return `<td class="py-4 px-4 border-b xl:text-sm text-xs font-semibold text-slate-500 text-center">${atasNama}</td><td class="py-4 px-4 border-b xl:text-sm text-xs font-semibold text-slate-500 text-center">${nomorRekening}</td><td class="py-4 px-4 border-b xl:text-sm text-xs font-semibold ${
    status ? "text-emerald-600" : "text-red-600"
  }  text-center">${status ? "Aktif" : "Tidak Aktif"}</td>`;
}
